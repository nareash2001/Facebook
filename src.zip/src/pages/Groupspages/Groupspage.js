import React from 'react'
import "./Groupspage.css"
const Groupspage = () => {
  return (
    <div>
      groupsss
    </div>
  )
}

export default Groupspage
