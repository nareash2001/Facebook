import React from 'react'
import "./Marketpage.css"
const Marketpage = () => {
  return (
    <div>
      Markett....
    </div>
  )
}

export default Marketpage
