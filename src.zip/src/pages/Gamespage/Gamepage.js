import React from 'react'
import "./Gamepage.css"
const Gamepage = () => {
  return (
    <div>
      gameee...
    </div>
  )
}

export default Gamepage
