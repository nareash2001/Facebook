import React from 'react'
import Homeleftnav from '../../components/Homeleftnav/Homeleftnav'

const Bookmark = () => {
  return (
    <Homeleftnav/>
  )
}

export default Bookmark
