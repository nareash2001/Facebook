
export const ContactList = [
    {
        img:"https://scontent.fmaa2-1.fna.fbcdn.net/v/t39.30808-1/328648065_1176545923228313_7015952107986727554_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=105&ccb=1-7&_nc_sid=7206a8&_nc_ohc=7FvfiFG7HwEAX-h3Kmt&_nc_ht=scontent.fmaa2-1.fna&oh=00_AfBwPIkx-wQK-EDhaBoaJHcs94x8VB0fBnEKbhz7uDtrHw&oe=64321083",
        name: "Sasi Anandh",
        active: 1,
        story: 0
    },
    {
        img:"https://scontent.fmaa2-1.fna.fbcdn.net/v/t39.30808-1/328648065_1176545923228313_7015952107986727554_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=105&ccb=1-7&_nc_sid=7206a8&_nc_ohc=7FvfiFG7HwEAX-h3Kmt&_nc_ht=scontent.fmaa2-1.fna&oh=00_AfBwPIkx-wQK-EDhaBoaJHcs94x8VB0fBnEKbhz7uDtrHw&oe=64321083",

        name: "Shanmuga",
        active: 0,
        story: 1
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 1
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 0,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 0,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 0,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 0,
        story: 1
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    }
]
export const Grouplist=[
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    },
    {
        img: "https://scontent.fmaa2-3.fna.fbcdn.net/v/t39.30808-1/276202347_2150814471771966_507197277566496472_n.jpg?stp=cp0_dst-jpg_p40x40&_nc_cat=103&ccb=1-7&_nc_sid=7206a8&_nc_ohc=y4rshHBIIXEAX-A4ycW&_nc_ht=scontent.fmaa2-3.fna&oh=00_AfATh_0drXvS-vL1yEpgGnAYJw4nQeGSoomow8IOR1vGtA&oe=642F5A03",

        name: "Nareah kumar",
        active: 1,
        story: 0
    }
]