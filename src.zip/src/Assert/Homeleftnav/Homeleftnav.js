export const Homeleftnavlist = [
    {
        img: "",
        name: "nareash",
        link: "profile",
        itag:0
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680525678/friend_bihccs.png",
        name: "Friends",
        link: "friends",
        itag:1
    },
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/yb/r/eECk3ceTaHJ.png",
        name: "Most Recent",
        link: "mostrecent",
        itag:0
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680525993/group_ntombx.png",
        name: "Groups",
        link: "/groups",
        itag:1
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680528027/watch_bx6fgy.png",
        name: "Watch",
        link: "watch",
        itag:1
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680583841/messenger_ojr68y.png",
        name: "Messenger",
        link: "messenger",
        itag:1
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680527721/market_dkdqi0.png",
        name: "Marketplace",
        link: "marketplace",
        itag:1
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680584511/clock_jefk34.png",
        name: "Memories",
        link: "memories",
        itag:1
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680528731/saved_lihnfp.png",
        name: "Saved",
        link: "saved",
        itag:1
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680527908/flag_1_e3dqm0.png",
        name: "Pages",
        link: "pages",
        itag:1
    },
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/CwKNCefmHON.png",
        name: "Ad Center",
        link: "adcenter",
        itag:0
    },
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/DHBHg9MEeSC.png",
        name: "Ads Manager",
        link: "admanager",
        itag:0
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680584121/blood_1_ocb94h.png",
        name: "Blood Donations",
        link: "blood",
        itag:1
    },
   
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/y3/r/Jr0q8qKF2-Y.png",
        name: "Climate Science Center",
        link: "climate",
        itag:0
    },
    
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/fNPcDZC-2PD.png",
        name: "Crisis response",
        link: "crisis",
        itag:0
    },
   
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/yx/r/WMOYDeEqIYv.png",
        name: "Events",
        link: "event",
        itag:0
    },
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/yK/r/mAnT0r8GSOm.png",
        name: "Favorites",
        link: "favorities",
        itag:0
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680528398/loveww_g3uprt.png",
        name: "Fundraisers",
        link: "fundraisers",
        itag:1
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680528598/game_kix3c0.png",
        name: "Gaming Video",
        link: "gamingvideo",
        itag:1
    },
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/yu/r/1Xvrz50fHMF.png",
        name: "Messenger Kids",
        link: "messengerkids",
        itag:0
    },
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/y3/r/JzYamtSussX.png",
        name: "Play Games",
        link: "gaming",
        itag:0
    },
    {
        img: "https://res.cloudinary.com/dym5bpsql/image/upload/v1680528185/live_1_kaqptq.png",
        name: "Live videos",
        link: "livevideo",
        itag:0
    },
   
    
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/yj/r/8OasGoQgQgF.png",
        name: "Recent ad activity",
        link: "recentadactivity",
        itag:0
    },
  
    {
        img: "https://static.xx.fbcdn.net/rsrc.php/v3/yz/r/oEGIppgu8A0.png",
        name: "Stories",
        link: "stories",
        itag:0
    },
   
];
export const Homeleftnavfooter=[
    {
     link:"#",
     name:"Privacy"
    },
    {
link:"#",
name:"Terms"
    },
    {
        link:"#",
        name:"Advertising"
    },
    {
        link:"#",
        name:'Ad Choices'
    },
    {
        link:"#",
        name:"Cookies"
    }
]