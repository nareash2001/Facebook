import React from 'react'
import "./Birthdays.css"
import Homeleftnavigated from "../../Homefriendsleftnavigated/Homefriendsleftnavigated"
const Birthdays = () => {
  return (
    <div>
      <Homeleftnavigated/>
    </div>
  )
}

export default Birthdays
