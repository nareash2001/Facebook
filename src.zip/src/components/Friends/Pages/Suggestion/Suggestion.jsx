import React from 'react'
import "./Suggestion.css"
const Suggestion = () => {
  return (
    <div>
      Suggestion
    </div>
  )
}

export default Suggestion
