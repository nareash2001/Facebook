import React from 'react'
import "./Allfriends.css"
const Allfriends = () => {
  return (
    <div>
      Allfriends
    </div>
  )
}

export default Allfriends
