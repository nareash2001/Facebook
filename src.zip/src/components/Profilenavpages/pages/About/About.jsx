import React from 'react'
import "./About.css"
const About = () => {
  return (
    <div>
      aboutji
    </div>
  )
}

export default About
