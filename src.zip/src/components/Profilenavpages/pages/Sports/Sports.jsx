import React from 'react'
import "./Sports.css"
const Sports = () => {
  return (
    <div>
      sports
    </div>
  )
}

export default Sports
