import React from 'react'
import "./Friend.css"
const Friend = () => {
  return (
    <div>
      Friend
    </div>
  )
}

export default Friend
