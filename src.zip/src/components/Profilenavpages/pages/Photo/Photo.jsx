import React from 'react'
import "./Photo.css"
const Photo = () => {
  return (
    <div>
      photos
    </div>
  )
}

export default Photo
