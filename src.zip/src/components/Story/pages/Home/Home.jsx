import React from 'react'
import "./Home.css"
const Home = () => {
    document.title="Facebook"
  return (
    <div className='storycreatepage displayflex'>
    <div className='storycreatepageleftnavi'>
    <div className='leftnavigate'>
        <div className='storyhomenaviheader'>
            Stories
        </div>
        <div className=''></div>
    </div>
    </div>
    </div>
  )
}

export default Home
