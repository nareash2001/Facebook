import React from 'react'
import "./Livepage.css"
const Livepage = () => {
  return (
    <div>
      Live
    </div>
  )
}

export default Livepage
