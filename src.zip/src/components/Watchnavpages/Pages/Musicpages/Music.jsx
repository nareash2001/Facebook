import React from 'react'
import "./Music.css"
const Music = () => {
  return (
    <div>
      music
    </div>
  )
}

export default Music
