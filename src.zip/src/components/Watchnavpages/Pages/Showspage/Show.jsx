import React from 'react'
import "./Show.css"
const Show = () => {
  return (
    <div>
      show
    </div>
  )
}

export default Show
