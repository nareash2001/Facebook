import React from 'react'
import "./Saved.css"
const Saved = () => {
  return (
    <div>
      saved
    </div>
  )
}

export default Saved
