import React from 'react'
import "./Message.css";
const Message = () => {
  return (
    <div>
      Message
    </div>
  )
}

export default Message
