import React from 'react'
import "./Menu.css"
const Menu = () => {
  return (
    <div>
      Menu
    </div>
  )
}

export default Menu
