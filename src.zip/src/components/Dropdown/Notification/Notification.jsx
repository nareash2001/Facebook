import React from 'react'
import "./Notification.css"
const Notification = () => {
  return (
    <div>
      notification
    </div>
  )
}

export default Notification
